export const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

export async function request(path: string, token?: string, options: RequestInit = {}) {
  const headers: Record<string,string> = {"Content-Type":"application/json", ...(options.headers as any || {})};
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(`${API}${path}`, {...options, headers});
  if (!res.ok) {
    let msg = `${res.status} ${res.statusText}`;
    try { const j = await res.json(); msg = j.detail || JSON.stringify(j); } catch {}
    throw new Error(msg);
  }
  if (res.status === 204) return null;
  return res.json();
}

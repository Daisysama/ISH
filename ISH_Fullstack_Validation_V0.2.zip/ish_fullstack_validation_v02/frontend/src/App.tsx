import { useEffect, useMemo, useState } from 'react';
import { request } from './api';

const DEFAULT_AGREEMENT = `ISH 共创协议草案\n\n1. 当前阶段为兴趣共创，不存在固定工资承诺。\n2. 各方已有 IP 仍归原权利人。\n3. 项目中新产生的共同成果，在商业化前由全体成员另行书面确认收益分配。\n4. 成员退出时，已提交成果的继续使用、署名和未来收益按本协议及后续版本处理。\n5. 任何协议修改都会生成新版本，旧版本不会被覆盖。`;

function App(){
  const [token,setToken]=useState(localStorage.getItem('ish_token')||'');
  const [me,setMe]=useState<any>(null);
  const [tab,setTab]=useState('projects');
  const [projects,setProjects]=useState<any[]>([]);
  const [selected,setSelected]=useState<any>(null);
  const [error,setError]=useState('');
  const [notice,setNotice]=useState('');

  async function loadMe(t=token){ if(!t) return; try{ setMe(await request('/me',t)); }catch{ logout(); } }
  async function loadProjects(){ setProjects(await request('/projects')); }
  async function openProject(id:number){ setSelected(await request(`/projects/${id}`)); setTab('project'); }
  function logout(){ localStorage.removeItem('ish_token');setToken('');setMe(null);setSelected(null); }
  function ok(msg:string){ setNotice(msg); setError(''); setTimeout(()=>setNotice(''),2500); }
  function fail(e:any){ setError(e.message||String(e)); }
  useEffect(()=>{ loadProjects(); if(token) loadMe(); },[]);

  if(!token) return <Login onLogin={(t:any,u:any)=>{localStorage.setItem('ish_token',t);setToken(t);setMe(u);}} />;

  return <div className="app">
    <header>
      <div><div className="brand">ISH <span>伊始</span></div><div className="tagline">Idea → People → Trust → Execution → Work → Audience</div></div>
      <div className="user"><b>{me?.display_name}</b><small>@{me?.username}{me?.is_editor?' · ISH Editor':''}</small><button onClick={logout}>退出</button></div>
    </header>
    <nav>
      <button className={tab==='projects'?'active':''} onClick={()=>{setTab('projects');loadProjects()}}>项目 / 发愿</button>
      <button className={tab==='create'?'active':''} onClick={()=>setTab('create')}>＋ 发一个愿</button>
      <button className={tab==='portfolio'?'active':''} onClick={()=>setTab('portfolio')}>我的履历</button>
      <button className={tab==='works'?'active':''} onClick={()=>setTab('works')}>作品 / Taste</button>
      <button className={tab==='audit'?'active':''} onClick={()=>setTab('audit')}>透明度日志</button>
    </nav>
    {error&&<div className="alert error">{error}<button onClick={()=>setError('')}>×</button></div>}
    {notice&&<div className="alert ok">{notice}</div>}
    <main>
      {tab==='projects'&&<Projects projects={projects} onOpen={openProject}/>} 
      {tab==='create'&&<CreateWish token={token} onDone={async(id:number)=>{ok('愿望已经落进数据库。');await loadProjects();await openProject(id)}} onError={fail}/>} 
      {tab==='project'&&selected&&<ProjectView token={token} me={me} project={selected} refresh={()=>openProject(selected.id)} onError={fail} onNotice={ok}/>} 
      {tab==='portfolio'&&<Portfolio token={token} me={me}/>} 
      {tab==='works'&&<Works token={token} me={me} onError={fail} onNotice={ok}/>} 
      {tab==='audit'&&<Audit/>}
    </main>
    <footer>ISH Full-stack Validation V0.2 · 真实 API / 数据库 / 权限 / 审计链 · 不是生产系统</footer>
  </div>
}

function Login({onLogin}:{onLogin:(t:string,u:any)=>void}){
  const [username,setUsername]=useState('liubang'); const [password,setPassword]=useState('demo123'); const [err,setErr]=useState('');
  async function go(){try{const r=await request('/auth/login',undefined,{method:'POST',body:JSON.stringify({username,password})});onLogin(r.token,r.user)}catch(e:any){setErr(e.message)}}
  return <div className="login"><div className="loginbox"><div className="brand big">ISH</div><h1>Full-stack Validation V0.2</h1><p>这次不是 LocalStorage。每个按钮都在打真实后端 API。</p>
    <label>用户名<input value={username} onChange={e=>setUsername(e.target.value)}/></label><label>密码<input type="password" value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="primary" onClick={go}>登录</button>
    {err&&<div className="errorText">{err}</div>}
    <div className="demo"><b>Demo 账号，密码均为 demo123</b>{['liubang','hanxin','zhangliang','editor'].map(x=><button key={x} onClick={()=>setUsername(x)}>{x}</button>)}</div>
  </div></div>
}

function Projects({projects,onOpen}:any){return <section><div className="sectionHead"><div><h2>愿望池</h2><p>不是职位列表。每张卡片首先回答：这群人到底想做什么？</p></div><span className="pill">UC-01 / UC-02</span></div>
<div className="grid">{projects.map((p:any)=><article className="card" key={p.id}><div className="eyebrow">#{p.id} · {p.economic_mode}</div><h3>{p.title}</h3><p>{p.summary}</p><div className="chips">{p.needs.map((n:any)=><span key={n.id}>{n.role_name}</span>)}</div><div className="meta">发起人 {p.owner.display_name} · {p.members.length} 人</div><button onClick={()=>onOpen(p.id)}>进入项目 →</button></article>)}</div>
{projects.length===0&&<div className="empty">数据库里还没有愿望。换到「发一个愿」创建第一条。</div>}</section>}

function CreateWish({token,onDone,onError}:any){
 const [f,setF]=useState({title:'',summary:'',goal:'',economic_mode:'interest',needs:'程序, 美术'});
 async function submit(){try{const p=await request('/projects',token,{method:'POST',body:JSON.stringify({...f,needs:f.needs.split(/[,，]/).map(x=>x.trim()).filter(Boolean)})});onDone(p.id)}catch(e){onError(e)}}
 return <section className="narrow"><div className="sectionHead"><div><h2>发一个愿</h2><p>把“我脑子里有个东西”变成别人可以响应的项目节点。</p></div><span className="pill">UC-01</span></div>
 <label>项目名<input value={f.title} onChange={e=>setF({...f,title:e.target.value})} placeholder="例如：两小时悬疑 Galgame"/></label>
 <label>一句话说清楚<input value={f.summary} onChange={e=>setF({...f,summary:e.target.value})}/></label>
 <label>目标<textarea value={f.goal} onChange={e=>setF({...f,goal:e.target.value})}/></label>
 <label>缺少角色（逗号分隔）<input value={f.needs} onChange={e=>setF({...f,needs:e.target.value})}/></label>
 <label>合作性质<select value={f.economic_mode} onChange={e=>setF({...f,economic_mode:e.target.value})}><option value="interest">兴趣共创</option><option value="commission">委托</option><option value="commercial">商业项目</option><option value="open-source">开源</option></select></label>
 <button className="primary" onClick={submit}>写进真实数据库</button></section>
}

function ProjectView({token,me,project,refresh,onError,onNotice}:any){
 const isOwner=project.owner.id===me.id; const isMember=project.members.some((m:any)=>m.user.id===me.id);
 const [apps,setApps]=useState<any[]>([]); const [agreement,setAgreement]=useState<any>(null); const [milestones,setMilestones]=useState<any[]>([]);
 const [apply,setApply]=useState({role_name:project.needs[0]?.role_name||'Contributor',note:'我对这个项目感兴趣，也能提供实际产出。',availability:'8h/week'});
 const [agreementText,setAgreementText]=useState(DEFAULT_AGREEMENT); const [mile,setMile]=useState('');
 async function loadExtras(){try{if(isOwner)setApps(await request(`/projects/${project.id}/applications`,token));if(isMember){setAgreement(await request(`/projects/${project.id}/agreements/current`,token));setMilestones(await request(`/projects/${project.id}/milestones`,token));}}catch(e){onError(e)}}
 useEffect(()=>{loadExtras()},[project.id, project.members.length]);
 async function applyNow(){try{await request(`/projects/${project.id}/applications`,token,{method:'POST',body:JSON.stringify(apply)});onNotice('申请已经写入后端。');}catch(e){onError(e)}}
 async function decide(id:number,decision:string){try{await request(`/applications/${id}/decision`,token,{method:'POST',body:JSON.stringify({decision})});onNotice(`申请已${decision==='accepted'?'接受':'拒绝'}`);await refresh();}catch(e){onError(e)}}
 async function newAgreement(){try{await request(`/projects/${project.id}/agreements`,token,{method:'POST',body:JSON.stringify({content:agreementText})});onNotice('生成了新的不可覆盖协议版本；旧签名不会自动继承。');await loadExtras()}catch(e){onError(e)}}
 async function sign(){try{await request(`/agreements/${agreement.id}/sign`,token,{method:'POST'});onNotice('签名已记录。');await loadExtras()}catch(e){onError(e)}}
 async function addMile(){try{await request(`/projects/${project.id}/milestones`,token,{method:'POST',body:JSON.stringify({title:mile,description:'由团队确认的关键航标'})});setMile('');await loadExtras()}catch(e){onError(e)}}
 async function complete(id:number){try{await request(`/milestones/${id}/complete`,token,{method:'POST'});await loadExtras()}catch(e){onError(e)}}
 async function deliver(id:number){const title=prompt('成果名称？','Playable Build v0.1');if(!title)return;const url=prompt('成果链接（可空）','https://example.com/build')||'';try{await request(`/milestones/${id}/deliverables`,token,{method:'POST',body:JSON.stringify({title,url,notes:'由真实项目成员提交'})});await loadExtras()}catch(e){onError(e)}}
 async function publish(){const title=prompt('作品名？',project.title+' Demo');if(!title)return;try{await request(`/projects/${project.id}/works`,token,{method:'POST',body:JSON.stringify({title,summary:'Born on ISH：从愿望到可展示成果。',external_url:'',commercial_relationship:'ISH has no commercial interest'})});onNotice('作品已发布到作品池。')}catch(e){onError(e)}}
 return <section><div className="sectionHead"><div><div className="eyebrow">PROJECT #{project.id}</div><h2>{project.title}</h2><p>{project.summary}</p></div><span className="pill">真实 Project ID</span></div>
 <div className="two"><div className="panel"><h3>目标</h3><p>{project.goal}</p><h3>成员</h3>{project.members.map((m:any)=><div className="row" key={m.id}><span>{m.user.display_name}</span><b>{m.role_name}</b></div>)}<h3>仍在寻找</h3><div className="chips">{project.needs.map((n:any)=><span key={n.id}>{n.role_name}</span>)}</div></div>
 <div className="panel"><h3>你的状态</h3><p>{isOwner?'你是项目发起人。':isMember?'你是正式项目成员。':'你尚未加入。'}</p>{!isMember&&!isOwner&&<><label>想承担的角色<input value={apply.role_name} onChange={e=>setApply({...apply,role_name:e.target.value})}/></label><label>为什么加入<textarea value={apply.note} onChange={e=>setApply({...apply,note:e.target.value})}/></label><button className="primary" onClick={applyNow}>愿同行</button></>}</div></div>
 {isOwner&&<div className="panel"><h3>加入申请 · 只有 Owner API 有权决定</h3>{apps.length===0?<p className="muted">暂无申请。可以退出后换 hanxin 账号申请。</p>:apps.map(a=><div className="application" key={a.id}><div><b>{a.applicant.display_name}</b> → {a.role_name}<p>{a.note}</p></div><div><span className="pill">{a.status}</span>{a.status==='pending'&&<><button onClick={()=>decide(a.id,'accepted')}>接受</button><button onClick={()=>decide(a.id,'rejected')}>拒绝</button></>}</div></div>)}</div>}
 {isMember&&<><div className="panel"><div className="sectionHead small"><div><h3>立契</h3><p>V1 签完后改成 V2，V1 签名不会迁移。</p></div><span className="pill">UC-03</span></div>{agreement?<><div className="agreement"><b>Version {agreement.version}</b><code>{agreement.content_hash}</code><pre>{agreement.content}</pre></div><p>已签：{agreement.signatures.map((s:any)=>s.display_name).join('、')||'无人'}</p><button onClick={sign}>签署当前版本</button></>:<p>尚无协议版本。</p>}{isOwner&&<><label>创建下一版本<textarea rows={7} value={agreementText} onChange={e=>setAgreementText(e.target.value)}/></label><button onClick={newAgreement}>生成新版本</button></>}</div>
 <div className="panel"><div className="sectionHead small"><div><h3>航标 / Milestones</h3><p>成员只提交成果和关键节点，不要求日报。</p></div><span className="pill">UC-04</span></div><div className="inline"><input value={mile} onChange={e=>setMile(e.target.value)} placeholder="例如 Prototype"/><button onClick={addMile}>新增航标</button></div>{milestones.map(m=><div className="mile" key={m.id}><div><b>{m.status==='completed'?'✓ ':''}{m.title}</b><small>{m.description}</small>{m.deliverables.map((d:any)=><a key={d.id} href={d.url||'#'} target="_blank">成果：{d.title}</a>)}</div><div><button onClick={()=>deliver(m.id)}>提交成果</button>{m.status!=='completed'&&<button onClick={()=>complete(m.id)}>确认完成</button>}</div></div>)}{isOwner&&<button className="primary" onClick={publish}>把项目发布成作品</button>}</div></>}
 </section>
}

function Portfolio({token,me}:any){const [data,setData]=useState<any>(null);useEffect(()=>{if(me)request(`/users/${me.id}/portfolio`).then(setData)},[me]);return <section><div className="sectionHead"><div><h2>Prove by Doing</h2><p>这个列表来自 project_members / projects，不是用户自由编一份简历。</p></div><span className="pill">UC-05</span></div>{data&&<><div className="profile"><h3>{data.user.display_name}</h3><p>{data.user.skills}</p></div>{data.projects.map((p:any)=><div className="portfolio" key={p.project_id}><b>{p.title}</b><span>{p.role}</span><small>{p.status}</small></div>)}</>}</section>}

function Works({token,me,onError,onNotice}:any){const [works,setWorks]=useState<any[]>([]);const [recs,setRecs]=useState<any[]>([]);const [taste,setTaste]=useState('slow-burn, story-rich');
 async function load(){setWorks(await request('/works'));setRecs(await request('/me/recommendations',token))}useEffect(()=>{load()},[]);
 async function saveTaste(){try{await request('/me/taste',token,{method:'PUT',body:JSON.stringify({tags:taste.split(/[,，]/).map(x=>x.trim()).filter(Boolean)})});await load();onNotice('Taste Profile 已更新，推荐顺序由后端重新计算。')}catch(e){onError(e)}}
 async function tags(id:number){const s=prompt('ISH编辑标签（逗号分隔）','slow-burn, story-rich');if(!s)return;try{await request(`/works/${id}/tags`,token,{method:'PUT',body:JSON.stringify({tags:s.split(/[,，]/).map(x=>x.trim()).filter(Boolean)})});await load()}catch(e){onError(e)}}
 return <section><div className="sectionHead"><div><h2>作品与 Taste Graph 雏形</h2><p>作品先被理解，再被推荐。编辑标签和商业关系都显式展示。</p></div><span className="pill">UC-06 / 07 / 08</span></div><div className="panel"><label>我的口味标签<input value={taste} onChange={e=>setTaste(e.target.value)}/></label><button onClick={saveTaste}>保存并重新推荐</button></div><h3>为你排序</h3><div className="grid">{recs.map(w=><article className="card" key={w.id}><div className="score">match {w.score}</div><h3>{w.title}</h3><p>{w.summary}</p><div className="chips">{w.tags.map((t:string)=><span key={t}>{t}</span>)}</div><small>{w.reason}</small><div className="disclosure">商业关系：{w.commercial_relationship}</div></article>)}</div><h3>全部作品</h3>{works.map(w=><div className="work" key={w.id}><div><b>{w.title}</b><span>Born on ISH · {w.project_title}</span><div className="chips">{w.tags.map((t:string)=><span key={t}>{t}</span>)}</div><small>商业关系：{w.commercial_relationship}</small></div>{me?.is_editor&&<button onClick={()=>tags(w.id)}>编辑策展标签</button>}</div>)}</section>}

function Audit(){const [logs,setLogs]=useState<any[]>([]);const [verify,setVerify]=useState<any>(null);async function load(){setLogs(await request('/audit'));setVerify(await request('/audit/verify'))}useEffect(()=>{load()},[]);return <section><div className="sectionHead"><div><h2>透明度 / Audit Chain</h2><p>关键行为写入追加式审计表；数据库触发器拒绝 UPDATE / DELETE。</p></div><span className={verify?.ok?'pill good':'pill bad'}>{verify?.ok?'HASH CHAIN OK':'CHAIN BROKEN'}</span></div><button onClick={load}>重新验证</button>{logs.map(l=><div className="audit" key={l.id}><b>#{l.id} {l.action}</b><span>{l.entity_type}:{l.entity_id}</span><code>{l.event_hash.slice(0,18)}…</code><small>{new Date(l.created_at).toLocaleString()}</small></div>)}</section>}

export default App;

# ISH V0.2 — 9 个核心 Use Case 覆盖表

| UC | 目标 | 当前实现 | 服务端约束 |
|---|---|---|---|
| UC-01 Create a Wish | 想法变成可响应项目 | `POST /projects` + `projects/project_needs` | 需登录；Owner 自动成为成员；写审计事件 |
| UC-02 Find Each Other | 申请并加入项目 | `applications` → Owner decision → `project_members` | 非 Owner 返回 403；同一用户不能重复申请 |
| UC-03 Build Trust | 版本化立契与签署 | `agreement_versions` + `agreement_signatures` | 新版本不继承旧签名；旧版本禁止继续签 |
| UC-04 Make It Happen | 航标、成果与完成 | `milestones` + `deliverables` | 仅项目成员可提交；完成行为写审计 |
| UC-05 Prove by Doing | 用真实项目形成履历 | `GET /users/{id}/portfolio` | 从项目成员关系派生，不提供“自填项目经历”接口 |
| UC-06 Publish the Work | 项目形成公开作品 | `POST /projects/{id}/works` | V0.2 仅 Owner 可发布；商业关系显式保存 |
| UC-07 Understand the Work | 编辑策展标签 | `PUT /works/{id}/tags` | 仅 `is_editor=true` 的账号可修改标签 |
| UC-08 Find the Audience | Taste → 推荐 | `taste_preferences` + tag overlap scoring | 推荐分数由服务端计算，不接受前端传分数 |
| UC-09 Trust the Platform | 关键行为可追溯 | `audit_logs` + hash chain + DB trigger | API 不提供修改/删除；数据库触发器拒绝 UPDATE/DELETE |

## 这版刻意没有做

- 支付、分账、众筹、股权或投资撮合
- 真正电子签名/CA 证书
- GitHub / Steam OAuth 与自动同步
- 文件对象存储
- 即时聊天
- 细粒度 RBAC / ABAC
- 邮件/短信通知
- 内容审核后台
- 审计日志的并发锁与外部时间戳锚定
- 生产级密钥管理、限流、WAF、S3、监控、告警

这些不是“忘了”，而是为了让 V0.2 的任务保持单一：**证明 9 个 UC 在真实前后端、真实数据库和权限边界下能连起来。**

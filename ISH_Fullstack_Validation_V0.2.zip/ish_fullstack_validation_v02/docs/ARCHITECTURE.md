# Architecture

```text
Browser / React SPA :5173
        |
        | JSON + Bearer JWT
        v
FastAPI :8000
        |
        | SQLAlchemy
        v
PostgreSQL :5432
```

核心对象：

```text
User
 ├─ owns → Project
 ├─ applies → Application → Project
 ├─ joins → ProjectMember → Project
 ├─ signs → AgreementSignature → AgreementVersion
 ├─ submits → Deliverable → Milestone
 └─ has → TastePreference

Project
 ├─ ProjectNeed
 ├─ ProjectMember
 ├─ AgreementVersion
 ├─ Milestone
 └─ Work → WorkTag

Every critical mutation
 └─ AuditLog(hash(prev + canonical_event))
```

## 为什么审计日志同时做两层保护

1. **应用层 hash chain**：可以验证事件顺序和内容有没有被重写。
2. **数据库层 trigger**：直接拒绝 `UPDATE audit_logs` 和 `DELETE FROM audit_logs`。

这仍不是生产级不可篡改账本。数据库超级管理员仍可以删除触发器、恢复备份或直接篡改物理文件。正式版本需要：独立审计服务、WORM/对象锁、异地副本、外部时间戳或 Merkle root 定期锚定。

## 权限模型（V0.2）

- Anonymous：看项目、作品、公开审计日志。
- Authenticated：发愿、申请项目、维护个人 Taste。
- Project Member：看协议、签协议、建航标、交成果。
- Project Owner：审核加入、创建协议新版本、发布作品。
- ISH Editor：给作品写策展标签。

这只是验证用最小 RBAC。未来需要把“项目 Owner”和“领航羊/Producer”分开，并增加 delegated permissions。

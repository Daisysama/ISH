import os
os.environ["DATABASE_URL"] = "sqlite:///./test_ish.db"
os.environ["JWT_SECRET"] = "test-secret-key-that-is-longer-than-32-bytes"

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text
from app.main import app
from app.database import Base, engine, install_audit_protection

@pytest.fixture(autouse=True)
def reset_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    install_audit_protection()
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c

def auth(client, username="liubang", password="demo123"):
    r=client.post("/auth/login",json={"username":username,"password":password})
    assert r.status_code==200, r.text
    return {"Authorization":f"Bearer {r.json()['token']}"}

@pytest.fixture
def headers_liubang(client): return auth(client,"liubang")
@pytest.fixture
def headers_hanxin(client): return auth(client,"hanxin")
@pytest.fixture
def headers_zhangliang(client): return auth(client,"zhangliang")
@pytest.fixture
def headers_editor(client): return auth(client,"editor")

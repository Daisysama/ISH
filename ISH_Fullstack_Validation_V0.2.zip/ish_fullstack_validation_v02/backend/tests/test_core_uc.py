from sqlalchemy import text
import pytest
from app.database import engine


def make_project(client, headers, title="大汉创业计划"):
    r=client.post("/projects",headers=headers,json={
        "title":title,"summary":"从一个愿望开始组队","goal":"完成可玩的独立游戏Demo","economic_mode":"interest",
        "needs":["Gameplay Engineer","Narrative Designer"]
    })
    assert r.status_code==200, r.text
    return r.json()


def apply_and_accept(client, project_id, applicant_headers, owner_headers):
    r=client.post(f"/projects/{project_id}/applications",headers=applicant_headers,json={"role_name":"Gameplay Engineer","note":"我来试试","availability":"10h/week"})
    assert r.status_code==200, r.text
    aid=r.json()["id"]
    r=client.post(f"/applications/{aid}/decision",headers=owner_headers,json={"decision":"accepted"})
    assert r.status_code==200, r.text
    return aid


def test_uc01_create_wish_persists(client, headers_liubang):
    p=make_project(client,headers_liubang)
    rows=client.get("/projects").json()
    assert any(x["id"]==p["id"] and x["title"]=="大汉创业计划" for x in rows)


def test_non_owner_cannot_accept_application(client, headers_liubang, headers_hanxin, headers_zhangliang):
    p=make_project(client,headers_liubang)
    r=client.post(f"/projects/{p['id']}/applications",headers=headers_hanxin,json={"role_name":"Engineer","note":"join","availability":"weekends"})
    aid=r.json()["id"]
    denied=client.post(f"/applications/{aid}/decision",headers=headers_zhangliang,json={"decision":"accepted"})
    assert denied.status_code==403


def test_uc02_accept_application_creates_membership(client, headers_liubang, headers_hanxin):
    p=make_project(client,headers_liubang)
    apply_and_accept(client,p["id"],headers_hanxin,headers_liubang)
    detail=client.get(f"/projects/{p['id']}").json()
    assert any(m["user"]["username"]=="hanxin" for m in detail["members"])


def test_uc03_new_agreement_version_requires_resign(client, headers_liubang, headers_hanxin):
    p=make_project(client,headers_liubang)
    apply_and_accept(client,p["id"],headers_hanxin,headers_liubang)
    v1=client.post(f"/projects/{p['id']}/agreements",headers=headers_liubang,json={"content":"V1: 兴趣共创，未来收益另行协商。"}).json()
    assert client.post(f"/agreements/{v1['id']}/sign",headers=headers_liubang).status_code==200
    assert client.post(f"/agreements/{v1['id']}/sign",headers=headers_hanxin).status_code==200
    current=client.get(f"/projects/{p['id']}/agreements/current",headers=headers_liubang).json()
    assert len(current["signatures"])==2
    v2=client.post(f"/projects/{p['id']}/agreements",headers=headers_liubang,json={"content":"V2: 收益按新规则协商。"}).json()
    current=client.get(f"/projects/{p['id']}/agreements/current",headers=headers_liubang).json()
    assert current["version"]==2 and current["signatures"]==[]
    old_sign=client.post(f"/agreements/{v1['id']}/sign",headers=headers_hanxin)
    assert old_sign.status_code==409


def test_uc04_milestone_and_deliverable_are_real_records(client, headers_liubang, headers_hanxin):
    p=make_project(client,headers_liubang)
    apply_and_accept(client,p["id"],headers_hanxin,headers_liubang)
    m=client.post(f"/projects/{p['id']}/milestones",headers=headers_hanxin,json={"title":"Prototype","description":"核心玩法可运行"}).json()
    d=client.post(f"/milestones/{m['id']}/deliverables",headers=headers_hanxin,json={"title":"Prototype Build","url":"https://example.com/build","notes":"v0.1"})
    assert d.status_code==200
    c=client.post(f"/milestones/{m['id']}/complete",headers=headers_liubang)
    assert c.status_code==200
    rows=client.get(f"/projects/{p['id']}/milestones",headers=headers_hanxin).json()
    assert rows[0]["status"]=="completed" and rows[0]["deliverables"][0]["title"]=="Prototype Build"


def test_uc05_portfolio_is_derived_from_membership_not_free_text(client, headers_liubang, headers_hanxin):
    p=make_project(client,headers_liubang)
    apply_and_accept(client,p["id"],headers_hanxin,headers_liubang)
    me=client.get("/me",headers=headers_hanxin).json()
    pf=client.get(f"/users/{me['id']}/portfolio").json()
    assert any(x["project_id"]==p["id"] and x["role"]=="Gameplay Engineer" for x in pf["projects"])


def test_uc06_publish_work_requires_owner(client, headers_liubang, headers_hanxin):
    p=make_project(client,headers_liubang)
    apply_and_accept(client,p["id"],headers_hanxin,headers_liubang)
    denied=client.post(f"/projects/{p['id']}/works",headers=headers_hanxin,json={"title":"Demo","summary":"x"})
    assert denied.status_code==403
    ok=client.post(f"/projects/{p['id']}/works",headers=headers_liubang,json={"title":"Demo","summary":"Playable demo","commercial_relationship":"ISH has no commercial interest"})
    assert ok.status_code==200


def test_uc07_editorial_tags_require_editor(client, headers_liubang, headers_hanxin, headers_editor):
    p=make_project(client,headers_liubang)
    wid=client.post(f"/projects/{p['id']}/works",headers=headers_liubang,json={"title":"Demo","summary":"Narrative demo"}).json()["id"]
    denied=client.put(f"/works/{wid}/tags",headers=headers_hanxin,json={"tags":["slow-burn","story-rich"]})
    assert denied.status_code==403
    ok=client.put(f"/works/{wid}/tags",headers=headers_editor,json={"tags":["slow-burn","story-rich"]})
    assert ok.status_code==200


def test_uc08_recommendation_uses_taste_tags(client, headers_liubang, headers_editor, headers_hanxin):
    p1=make_project(client,headers_liubang,"慢热科幻RPG")
    w1=client.post(f"/projects/{p1['id']}/works",headers=headers_liubang,json={"title":"星海","summary":"慢热叙事"}).json()["id"]
    client.put(f"/works/{w1}/tags",headers=headers_editor,json={"tags":["slow-burn","story-rich"]})
    p2=make_project(client,headers_liubang,"高速动作游戏")
    w2=client.post(f"/projects/{p2['id']}/works",headers=headers_liubang,json={"title":"闪击","summary":"高速动作"}).json()["id"]
    client.put(f"/works/{w2}/tags",headers=headers_editor,json={"tags":["action","fast"]})
    client.put("/me/taste",headers=headers_hanxin,json={"tags":["slow-burn","story-rich"]})
    recs=client.get("/me/recommendations",headers=headers_hanxin).json()
    assert recs[0]["id"]==w1 and recs[0]["score"]==2


def test_uc09_audit_chain_verifies_and_db_rejects_mutation(client, headers_liubang):
    make_project(client,headers_liubang)
    v=client.get("/audit/verify").json()
    assert v["ok"] is True
    with pytest.raises(Exception):
        with engine.begin() as conn:
            conn.execute(text("UPDATE audit_logs SET action='tampered' WHERE id=1"))


def test_audit_contains_critical_events(client, headers_liubang):
    p=make_project(client,headers_liubang)
    logs=client.get("/audit").json()
    assert any(x["action"]=="project.create" and x["entity_id"]==str(p["id"]) for x in logs)

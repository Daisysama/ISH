import hashlib, json
from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.orm import Session
from .models import AuditLog

def _canonical(data):
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

def append_audit(db: Session, actor_user_id, action, entity_type, entity_id, payload):
    latest = db.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(1)).scalar_one_or_none()
    prev_hash = latest.event_hash if latest else ""
    envelope = {
        "actor_user_id": actor_user_id,
        "action": action,
        "entity_type": entity_type,
        "entity_id": str(entity_id),
        "payload": payload,
        "prev_hash": prev_hash,
    }
    event_hash = hashlib.sha256(_canonical(envelope).encode()).hexdigest()
    row = AuditLog(
        actor_user_id=actor_user_id,
        action=action,
        entity_type=entity_type,
        entity_id=str(entity_id),
        payload_json=_canonical(payload),
        prev_hash=prev_hash,
        event_hash=event_hash,
    )
    db.add(row)
    db.flush()
    return row

def verify_chain(db: Session):
    rows = db.execute(select(AuditLog).order_by(AuditLog.id.asc())).scalars().all()
    prev = ""
    for row in rows:
        payload = json.loads(row.payload_json)
        envelope = {
            "actor_user_id": row.actor_user_id,
            "action": row.action,
            "entity_type": row.entity_type,
            "entity_id": row.entity_id,
            "payload": payload,
            "prev_hash": prev,
        }
        expected = hashlib.sha256(_canonical(envelope).encode()).hexdigest()
        if row.prev_hash != prev or row.event_hash != expected:
            return False, row.id
        prev = row.event_hash
    return True, None

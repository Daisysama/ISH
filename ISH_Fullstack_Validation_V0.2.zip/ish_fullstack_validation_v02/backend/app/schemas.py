from pydantic import BaseModel, Field
from typing import List, Optional

class LoginIn(BaseModel):
    username: str
    password: str

class RegisterIn(BaseModel):
    username: str
    display_name: str
    password: str = Field(min_length=6)
    skills: str = ""

class ProjectCreate(BaseModel):
    title: str
    summary: str
    goal: str
    economic_mode: str = "interest"
    needs: List[str] = []

class ApplicationCreate(BaseModel):
    role_name: str
    note: str
    availability: str = ""

class ApplicationDecision(BaseModel):
    decision: str

class AgreementCreate(BaseModel):
    content: str

class MilestoneCreate(BaseModel):
    title: str
    description: str = ""
    owner_id: Optional[int] = None

class DeliverableCreate(BaseModel):
    title: str
    url: str = ""
    notes: str = ""

class WorkCreate(BaseModel):
    title: str
    summary: str
    external_url: str = ""
    commercial_relationship: str = "No ISH commercial relationship disclosed"

class WorkTagsIn(BaseModel):
    tags: List[str]

class TasteIn(BaseModel):
    tags: List[str]

from contextlib import asynccontextmanager
from datetime import datetime, timezone
import hashlib, json, os
from typing import Annotated

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy import select, func, text
from sqlalchemy.orm import Session

from .database import Base, engine, get_db, SessionLocal, install_audit_protection
from .models import *
from .schemas import *
from .auth import hash_password, verify_password, create_token, decode_token
from .audit import append_audit, verify_chain

security = HTTPBearer(auto_error=False)

def seed_demo_users():
    db = SessionLocal()
    try:
        demos = [
            ("liubang", "刘邦", "founder, producer, storytelling", False),
            ("hanxin", "韩信", "gameplay, engineering, systems", False),
            ("zhangliang", "张良", "strategy, writing, design", False),
            ("editor", "ISH编辑", "curation, review, audience research", True),
        ]
        for username, display, skills, is_editor in demos:
            if not db.execute(select(User).where(User.username == username)).scalar_one_or_none():
                db.add(User(username=username, display_name=display, password_hash=hash_password("demo123"), skills=skills, is_editor=is_editor))
        db.commit()
    finally:
        db.close()

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    install_audit_protection()
    seed_demo_users()
    yield

app = FastAPI(title="ISH Full-stack Validation API", version="0.2", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def current_user(
    creds: Annotated[HTTPAuthorizationCredentials | None, Depends(security)],
    db: Annotated[Session, Depends(get_db)]
) -> User:
    if not creds:
        raise HTTPException(status_code=401, detail="Missing bearer token")
    try:
        uid = decode_token(creds.credentials)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = db.get(User, uid)
    if not user:
        raise HTTPException(status_code=401, detail="Unknown user")
    return user

def is_project_member(db: Session, project_id: int, user_id: int) -> bool:
    p = db.get(Project, project_id)
    if not p: return False
    if p.owner_id == user_id: return True
    return db.execute(select(ProjectMember).where(ProjectMember.project_id==project_id, ProjectMember.user_id==user_id)).scalar_one_or_none() is not None

def user_out(u: User):
    return {"id":u.id,"username":u.username,"display_name":u.display_name,"skills":u.skills,"bio":u.bio,"is_editor":u.is_editor}

def project_out(db: Session, p: Project):
    owner = db.get(User, p.owner_id)
    needs = db.execute(select(ProjectNeed).where(ProjectNeed.project_id==p.id)).scalars().all()
    members = db.execute(select(ProjectMember).where(ProjectMember.project_id==p.id)).scalars().all()
    return {
        "id":p.id,"title":p.title,"summary":p.summary,"goal":p.goal,"status":p.status,"economic_mode":p.economic_mode,
        "owner": user_out(owner), "needs":[{"id":n.id,"role_name":n.role_name,"description":n.description} for n in needs],
        "members":[{"id":m.id,"user":user_out(db.get(User,m.user_id)),"role_name":m.role_name,"joined_at":m.joined_at.isoformat()} for m in members],
        "created_at":p.created_at.isoformat()
    }

@app.get("/health")
def health():
    return {"ok": True, "service": "ish-api", "version": "0.2"}

@app.post("/auth/register")
def register(data: RegisterIn, db: Session = Depends(get_db)):
    if db.execute(select(User).where(User.username==data.username)).scalar_one_or_none():
        raise HTTPException(409, "Username already exists")
    u=User(username=data.username, display_name=data.display_name, password_hash=hash_password(data.password), skills=data.skills)
    db.add(u); db.flush(); append_audit(db,u.id,"user.register","user",u.id,{"username":u.username}); db.commit(); db.refresh(u)
    return {"token":create_token(u.id),"user":user_out(u)}

@app.post("/auth/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    u=db.execute(select(User).where(User.username==data.username)).scalar_one_or_none()
    if not u or not verify_password(data.password,u.password_hash): raise HTTPException(401,"Invalid credentials")
    return {"token":create_token(u.id),"user":user_out(u)}

@app.get("/me")
def me(user: User = Depends(current_user)): return user_out(user)

@app.get("/projects")
def list_projects(db: Session=Depends(get_db)):
    ps=db.execute(select(Project).order_by(Project.id.desc())).scalars().all()
    return [project_out(db,p) for p in ps]

@app.post("/projects")
def create_project(data: ProjectCreate, user: User=Depends(current_user), db: Session=Depends(get_db)):
    p=Project(title=data.title, summary=data.summary, goal=data.goal, owner_id=user.id, economic_mode=data.economic_mode)
    db.add(p); db.flush()
    for role in data.needs: db.add(ProjectNeed(project_id=p.id, role_name=role.strip()))
    db.add(ProjectMember(project_id=p.id,user_id=user.id,role_name="Initiator / Lead"))
    append_audit(db,user.id,"project.create","project",p.id,{"title":p.title,"economic_mode":p.economic_mode,"needs":data.needs})
    db.commit(); db.refresh(p); return project_out(db,p)

@app.get("/projects/{project_id}")
def get_project(project_id:int, db: Session=Depends(get_db)):
    p=db.get(Project,project_id)
    if not p: raise HTTPException(404,"Project not found")
    return project_out(db,p)

@app.post("/projects/{project_id}/applications")
def apply(project_id:int,data:ApplicationCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    p=db.get(Project,project_id)
    if not p: raise HTTPException(404,"Project not found")
    if is_project_member(db,project_id,user.id): raise HTTPException(409,"Already a project member")
    if db.execute(select(Application).where(Application.project_id==project_id,Application.applicant_id==user.id)).scalar_one_or_none(): raise HTTPException(409,"Already applied")
    a=Application(project_id=project_id,applicant_id=user.id,role_name=data.role_name,note=data.note,availability=data.availability)
    db.add(a);db.flush();append_audit(db,user.id,"application.create","application",a.id,{"project_id":project_id,"role_name":a.role_name});db.commit();db.refresh(a)
    return {"id":a.id,"status":a.status}

@app.get("/projects/{project_id}/applications")
def applications(project_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    p=db.get(Project,project_id)
    if not p: raise HTTPException(404,"Project not found")
    if p.owner_id != user.id: raise HTTPException(403,"Only project owner can review applications")
    rows=db.execute(select(Application).where(Application.project_id==project_id).order_by(Application.id.desc())).scalars().all()
    return [{"id":a.id,"role_name":a.role_name,"note":a.note,"availability":a.availability,"status":a.status,"applicant":user_out(db.get(User,a.applicant_id))} for a in rows]

@app.post("/applications/{application_id}/decision")
def decide_application(application_id:int,data:ApplicationDecision,user:User=Depends(current_user),db:Session=Depends(get_db)):
    a=db.get(Application,application_id)
    if not a: raise HTTPException(404,"Application not found")
    p=db.get(Project,a.project_id)
    if p.owner_id != user.id: raise HTTPException(403,"Only project owner can decide")
    if a.status != "pending": raise HTTPException(409,"Application already decided")
    if data.decision not in {"accepted","rejected"}: raise HTTPException(422,"decision must be accepted or rejected")
    a.status=data.decision
    if data.decision=="accepted": db.add(ProjectMember(project_id=a.project_id,user_id=a.applicant_id,role_name=a.role_name))
    append_audit(db,user.id,"application.decision","application",a.id,{"decision":data.decision,"project_id":a.project_id,"applicant_id":a.applicant_id});db.commit()
    return {"ok":True,"status":a.status}

@app.get("/projects/{project_id}/agreements/current")
def current_agreement(project_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if not is_project_member(db,project_id,user.id): raise HTTPException(403,"Project members only")
    av=db.execute(select(AgreementVersion).where(AgreementVersion.project_id==project_id).order_by(AgreementVersion.version.desc()).limit(1)).scalar_one_or_none()
    if not av: return None
    sigs=db.execute(select(AgreementSignature).where(AgreementSignature.agreement_version_id==av.id)).scalars().all()
    return {"id":av.id,"project_id":av.project_id,"version":av.version,"content":av.content,"content_hash":av.content_hash,"signatures":[{"user_id":s.user_id,"display_name":db.get(User,s.user_id).display_name,"signed_at":s.signed_at.isoformat()} for s in sigs]}

@app.post("/projects/{project_id}/agreements")
def new_agreement(project_id:int,data:AgreementCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    p=db.get(Project,project_id)
    if not p: raise HTTPException(404,"Project not found")
    if p.owner_id != user.id: raise HTTPException(403,"Only project owner can create agreement versions in V0.2")
    latest=db.execute(select(func.max(AgreementVersion.version)).where(AgreementVersion.project_id==project_id)).scalar_one()
    v=(latest or 0)+1
    content_hash=hashlib.sha256(data.content.encode()).hexdigest()
    av=AgreementVersion(project_id=project_id,version=v,content=data.content,content_hash=content_hash,created_by=user.id)
    db.add(av);db.flush();append_audit(db,user.id,"agreement.version.create","agreement_version",av.id,{"project_id":project_id,"version":v,"content_hash":content_hash});db.commit();db.refresh(av)
    return {"id":av.id,"version":av.version,"content_hash":av.content_hash}

@app.post("/agreements/{agreement_version_id}/sign")
def sign_agreement(agreement_version_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    av=db.get(AgreementVersion,agreement_version_id)
    if not av: raise HTTPException(404,"Agreement not found")
    latest=db.execute(select(func.max(AgreementVersion.version)).where(AgreementVersion.project_id==av.project_id)).scalar_one()
    if av.version != latest: raise HTTPException(409,"Only current agreement version can be signed")
    if not is_project_member(db,av.project_id,user.id): raise HTTPException(403,"Project members only")
    existing=db.execute(select(AgreementSignature).where(AgreementSignature.agreement_version_id==av.id,AgreementSignature.user_id==user.id)).scalar_one_or_none()
    if existing: return {"ok":True,"already_signed":True}
    s=AgreementSignature(agreement_version_id=av.id,user_id=user.id);db.add(s);db.flush();append_audit(db,user.id,"agreement.sign","agreement_version",av.id,{"project_id":av.project_id,"version":av.version,"content_hash":av.content_hash});db.commit()
    return {"ok":True,"already_signed":False}

@app.get("/projects/{project_id}/milestones")
def list_milestones(project_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if not is_project_member(db,project_id,user.id): raise HTTPException(403,"Project members only")
    rows=db.execute(select(Milestone).where(Milestone.project_id==project_id).order_by(Milestone.id.asc())).scalars().all()
    result=[]
    for m in rows:
        dels=db.execute(select(Deliverable).where(Deliverable.milestone_id==m.id)).scalars().all()
        result.append({"id":m.id,"title":m.title,"description":m.description,"status":m.status,"owner_id":m.owner_id,"completed_at":m.completed_at.isoformat() if m.completed_at else None,"deliverables":[{"id":d.id,"title":d.title,"url":d.url,"notes":d.notes,"submitted_by":d.submitted_by} for d in dels]})
    return result

@app.post("/projects/{project_id}/milestones")
def create_milestone(project_id:int,data:MilestoneCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if not is_project_member(db,project_id,user.id): raise HTTPException(403,"Project members only")
    m=Milestone(project_id=project_id,title=data.title,description=data.description,owner_id=data.owner_id or user.id)
    db.add(m);db.flush();append_audit(db,user.id,"milestone.create","milestone",m.id,{"project_id":project_id,"title":m.title});db.commit();db.refresh(m)
    return {"id":m.id,"status":m.status}

@app.post("/milestones/{milestone_id}/deliverables")
def add_deliverable(milestone_id:int,data:DeliverableCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    m=db.get(Milestone,milestone_id)
    if not m: raise HTTPException(404,"Milestone not found")
    if not is_project_member(db,m.project_id,user.id): raise HTTPException(403,"Project members only")
    d=Deliverable(milestone_id=m.id,submitted_by=user.id,title=data.title,url=data.url,notes=data.notes)
    db.add(d);db.flush();append_audit(db,user.id,"deliverable.add","deliverable",d.id,{"milestone_id":m.id,"title":d.title,"url":d.url});db.commit();return {"id":d.id}

@app.post("/milestones/{milestone_id}/complete")
def complete_milestone(milestone_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    m=db.get(Milestone,milestone_id)
    if not m: raise HTTPException(404,"Milestone not found")
    if not is_project_member(db,m.project_id,user.id): raise HTTPException(403,"Project members only")
    m.status="completed";m.completed_at=datetime.now(timezone.utc);append_audit(db,user.id,"milestone.complete","milestone",m.id,{"project_id":m.project_id,"title":m.title});db.commit();return {"ok":True}

@app.get("/users/{user_id}/portfolio")
def portfolio(user_id:int,db:Session=Depends(get_db)):
    u=db.get(User,user_id)
    if not u: raise HTTPException(404,"User not found")
    owned=db.execute(select(Project).where(Project.owner_id==user_id)).scalars().all()
    memberships=db.execute(select(ProjectMember).where(ProjectMember.user_id==user_id)).scalars().all()
    seen=set(); projects=[]
    for p in owned:
        projects.append({"project_id":p.id,"title":p.title,"role":"Initiator / Lead","status":p.status}); seen.add(p.id)
    for m in memberships:
        if m.project_id in seen: continue
        p=db.get(Project,m.project_id); projects.append({"project_id":p.id,"title":p.title,"role":m.role_name,"status":p.status}); seen.add(m.project_id)
    return {"user":user_out(u),"projects":projects}

@app.post("/projects/{project_id}/works")
def publish_work(project_id:int,data:WorkCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    p=db.get(Project,project_id)
    if not p: raise HTTPException(404,"Project not found")
    if p.owner_id != user.id: raise HTTPException(403,"Only project owner can publish work in V0.2")
    w=Work(project_id=project_id,title=data.title,summary=data.summary,external_url=data.external_url,commercial_relationship=data.commercial_relationship)
    db.add(w);db.flush();append_audit(db,user.id,"work.publish","work",w.id,{"project_id":project_id,"title":w.title,"commercial_relationship":w.commercial_relationship});db.commit();db.refresh(w)
    return {"id":w.id}

@app.get("/works")
def list_works(db:Session=Depends(get_db)):
    ws=db.execute(select(Work).order_by(Work.id.desc())).scalars().all(); out=[]
    for w in ws:
        tags=db.execute(select(WorkTag).where(WorkTag.work_id==w.id)).scalars().all(); p=db.get(Project,w.project_id)
        out.append({"id":w.id,"project_id":w.project_id,"project_title":p.title,"title":w.title,"summary":w.summary,"external_url":w.external_url,"commercial_relationship":w.commercial_relationship,"tags":[t.tag for t in tags]})
    return out

@app.put("/works/{work_id}/tags")
def set_work_tags(work_id:int,data:WorkTagsIn,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if not user.is_editor: raise HTTPException(403,"ISH editor role required")
    w=db.get(Work,work_id)
    if not w: raise HTTPException(404,"Work not found")
    db.query(WorkTag).filter(WorkTag.work_id==work_id).delete(synchronize_session=False)
    for tag in sorted(set(t.strip() for t in data.tags if t.strip())): db.add(WorkTag(work_id=work_id,tag=tag,value=1.0))
    append_audit(db,user.id,"work.tags.replace","work",work_id,{"tags":sorted(set(data.tags))});db.commit();return {"ok":True}

@app.put("/me/taste")
def set_taste(data:TasteIn,user:User=Depends(current_user),db:Session=Depends(get_db)):
    db.query(TastePreference).filter(TastePreference.user_id==user.id).delete(synchronize_session=False)
    for tag in sorted(set(t.strip() for t in data.tags if t.strip())): db.add(TastePreference(user_id=user.id,tag=tag,weight=1.0))
    append_audit(db,user.id,"taste.replace","user",user.id,{"tags":sorted(set(data.tags))});db.commit();return {"ok":True}

@app.get("/me/recommendations")
def recommendations(user:User=Depends(current_user),db:Session=Depends(get_db)):
    prefs={p.tag:p.weight for p in db.execute(select(TastePreference).where(TastePreference.user_id==user.id)).scalars().all()}
    ws=db.execute(select(Work)).scalars().all(); scored=[]
    for w in ws:
        tags=[t.tag for t in db.execute(select(WorkTag).where(WorkTag.work_id==w.id)).scalars().all()]
        score=sum(prefs.get(t,0) for t in tags)
        scored.append({"id":w.id,"title":w.title,"summary":w.summary,"tags":tags,"score":score,"reason":f"Matched {int(score)} taste tag(s)" if score else "No explicit taste match yet","commercial_relationship":w.commercial_relationship})
    return sorted(scored,key=lambda x:(x["score"],x["id"]),reverse=True)

@app.get("/audit")
def audit_logs(limit:int=100,db:Session=Depends(get_db)):
    rows=db.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(min(limit,500))).scalars().all()
    return [{"id":r.id,"actor_user_id":r.actor_user_id,"action":r.action,"entity_type":r.entity_type,"entity_id":r.entity_id,"payload":json.loads(r.payload_json),"prev_hash":r.prev_hash,"event_hash":r.event_hash,"created_at":r.created_at.isoformat()} for r in rows]

@app.get("/audit/verify")
def audit_verify(db:Session=Depends(get_db)):
    ok,bad_id=verify_chain(db);return {"ok":ok,"first_bad_id":bad_id}
